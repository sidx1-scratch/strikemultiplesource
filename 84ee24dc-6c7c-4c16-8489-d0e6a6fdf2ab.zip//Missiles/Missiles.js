/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Missiles extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Missiles/costumes/costume1.svg", {
        x: 18.625940000000014,
        y: 13.066878094024275,
      }),
    ];

    this.sounds = [new Sound("recording1", "./Missiles/sounds/recording1.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game over" },
        this.whenIReceiveGameOver2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "start" },
        this.whenIReceiveStart2
      ),
    ];
  }

  *startAsClone() {
    this.broadcast("Cloud-Tick");
    yield* this.missile(10);
  }

  *cloneFactory(secs) {
    while (true) {
      if (this.mouse.down || this.keyPressed("space")) {
        yield* this.wait(this.toNumber(secs));
        this.createClone();
      }
      yield;
    }
  }

  *missile(speed) {
    this.visible = true;
    yield* this.startSound("recording1");
    this.goto(
      this.sprites["PlayerSpaceShip"].x,
      this.sprites["PlayerSpaceShip"].y
    );
    this.direction = this.sprites["PlayerSpaceShip"].direction;
    while (!this.touching("edge")) {
      this.move(this.toNumber(speed));
      yield;
    }
    this.deleteThisClone();
  }

  *whenIReceiveStart() {
    yield* this.cloneFactory(0.1);
  }

  *whenIReceiveGameOver() {
    this.deleteThisClone();
  }

  *whenIReceiveGameOver2() {
    while (!(this.toNumber(this.stage.vars.start) === 1)) {
      this.deleteThisClone();
      yield;
    }
  }

  *whenIReceiveStart2() {
    this.visible = false;
    this.deleteThisClone();
  }
}
