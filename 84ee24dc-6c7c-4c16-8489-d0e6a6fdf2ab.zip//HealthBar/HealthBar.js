/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class HealthBar extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("h1", "./HealthBar/costumes/h1.svg", {
        x: 21,
        y: 2.8333450000000084,
      }),
      new Costume("h2", "./HealthBar/costumes/h2.svg", {
        x: 21,
        y: 2.8333350000000337,
      }),
      new Costume("h3", "./HealthBar/costumes/h3.svg", {
        x: 21,
        y: 2.833335000000062,
      }),
      new Costume("h4", "./HealthBar/costumes/h4.svg", {
        x: 21,
        y: 2.8333350000000053,
      }),
      new Costume("h5", "./HealthBar/costumes/h5.svg", {
        x: 21,
        y: 2.833335000000119,
      }),
      new Costume("h6", "./HealthBar/costumes/h6.svg", {
        x: 21,
        y: 2.8333350000001474,
      }),
      new Costume("h7", "./HealthBar/costumes/h7.svg", {
        x: 21,
        y: 2.833335000000176,
      }),
      new Costume("h8", "./HealthBar/costumes/h8.svg", {
        x: 21,
        y: 2.833335000000204,
      }),
      new Costume("h9", "./HealthBar/costumes/h9.svg", {
        x: 21,
        y: 2.833335000000204,
      }),
      new Costume("h10", "./HealthBar/costumes/h10.svg", {
        x: 21,
        y: 2.8333350000002326,
      }),
      new Costume("h11", "./HealthBar/costumes/h11.svg", {
        x: 21,
        y: 2.833335000000261,
      }),
    ];

    this.sounds = [new Sound("pop", "./HealthBar/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.healths = [];
  }

  *startAsClone() {
    this.x = this.toNumber(this.itemOf(this.stage.vars.healths, 0));
    this.y = this.toNumber(this.itemOf(this.stage.vars.healths, 1));
    this.costume = 10 * this.toNumber(this.itemOf(this.stage.vars.healths, 2));
    this.stage.vars.healths.splice(0, 1);
    this.stage.vars.healths.splice(0, 1);
    this.stage.vars.healths.splice(0, 1);
    if (!this.touching("edge")) {
      this.moveAhead();
      this.visible = true;
      yield* this.wait(0);
    }
    this.deleteThisClone();
  }

  *showHealthBarOfOffsetY(health, max, y) {
    this.stage.vars.healths.push(this.x);
    this.stage.vars.healths.push(this.y + this.toNumber(y));
    this.stage.vars.healths.push(this.toNumber(health) / this.toNumber(max));
    this.sprites["HealthBar"].createClone();
  }
}
