/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class TimeOrOnMobileEnemyPoint extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "costume1",
        "./TimeOrOnMobileEnemyPoint/costumes/costume1.svg",
        { x: 0, y: 0 }
      ),
    ];

    this.sounds = [
      new Sound("pop", "./TimeOrOnMobileEnemyPoint/sounds/pop.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenIReceiveStart() {
    this.visible = true;
    while (true) {
      yield* this.wait(1);
      this.stage.vars.time++;
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.time = 0;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.stage.vars.username = /* no username */ "";
      yield;
    }
  }
}
