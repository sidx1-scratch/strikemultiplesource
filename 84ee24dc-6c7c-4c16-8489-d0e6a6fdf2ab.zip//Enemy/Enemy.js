/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Enemy extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Enemy/costumes/costume1.svg", {
        x: 47.91758233211735,
        y: 47.91754004238041,
      }),
      new Costume("costume2", "./Enemy/costumes/costume2.svg", {
        x: 55.18197412544714,
        y: 47.91754004238038,
      }),
      new Costume("costume3", "./Enemy/costumes/costume3.svg", {
        x: 56.8060429908318,
        y: 55.518360921604426,
      }),
      new Costume("costume4", "./Enemy/costumes/costume4.svg", {
        x: 88.74606401006253,
        y: 71.75904957545058,
      }),
      new Costume("costume5", "./Enemy/costumes/costume5.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("Meow", "./Enemy/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart),
      new Trigger(
        Trigger.BROADCAST,
        { name: "start" },
        this.whenIReceiveStart2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.BROADCAST, { name: "boss" }, this.whenIReceiveBoss),
    ];

    this.vars.health = 0;
  }

  *movmemet(steps) {
    this.move(this.toNumber(steps));
    yield* this.showHealthBarOfOffsetY(this.vars.health, 100, 30);
    this.direction = this.radToScratch(
      Math.atan2(
        this.sprites["PlayerSpaceShip"].y - this.y,
        this.sprites["PlayerSpaceShip"].x - this.x
      )
    );
    if (this.touching(this.sprites["Missiles"].andClones())) {
      this.vars.health -= 30;
      yield* this.wait(0.01);
      this.costumeNumber++;
      if (this.compare(this.vars.health, 1) < 0) {
        this.stage.vars.aliveOrNotEnemy = 1;
        this.stage.vars.score += 100;
        this.deleteThisClone();
      }
    }
    if (this.touching(this.sprites["PlayerSpaceShip"].andClones())) {
      this.vars.health -= 30;
      if (this.compare(this.vars.health, 1) < 0) {
        this.stage.vars.score += 100;
        this.deleteThisClone();
      }
    }
    if (
      this.toNumber(this.stage.vars.score) === 800000 ||
      this.compare(this.stage.vars.score, 800000) > 0
    ) {
      this.broadcast("boss");
    }
  }

  *startAsClone() {
    this.costume = "costume1";
    this.vars.health = 100;
    if (this.toNumber(this.stage.vars.talk) === 0) {
      yield* this.cloningForMovement(0.6);
    }
    if (this.toNumber(this.stage.vars.talk) === 1) {
      this.visible = false;
      this.deleteThisClone();
    }
    /* TODO: Implement sensing_setdragmode */ null;
    while (true) {
      this.stage.vars.myValuesToSend.push(this.x);
      this.stage.vars.myValuesToSend.push(this.y);
      this.stage.vars.myValuesToSend.push(this.direction);
      this.stage.vars.myValuesToSend.push(this.stage.vars.cloneNumer);
      this.broadcast("Cloud-Tick");
      yield;
    }
  }

  *whenIReceiveStart() {
    this.stage.vars.aliveOrNotEnemy = 0;
    this.visible = false;
    while (true) {
      this.goto(this.random(-240, 240), this.random(-180, 180));
      yield* this.wait(this.random(0.01, 0.5));
      this.createClone();
      this.stage.vars.cloneNumer++;
      yield;
    }
  }

  *whenIReceiveStart2() {
    this.deleteThisClone();
  }

  *whenIReceiveGameOver() {
    this.deleteThisClone();
  }

  *cloningForMovement(steps) {
    this.goto(this.random(-240, 240), 144);
    this.visible = true;
    this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
    while (true) {
      yield* this.movmemet(steps);
      yield;
    }
  }

  *showHealthBarOfOffsetY(health, max, y) {
    this.stage.vars.healths.push(this.x);
    this.stage.vars.healths.push(this.y + this.toNumber(y));
    this.stage.vars.healths.push(this.toNumber(health) / this.toNumber(max));
    this.sprites["HealthBar"].createClone();
  }

  *whenIReceiveBoss() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
