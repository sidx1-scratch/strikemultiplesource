import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Missiles from "./Missiles/Missiles.js";
import PlayerSpaceShip from "./PlayerSpaceShip/PlayerSpaceShip.js";
import CloudPlayer from "./CloudPlayer/CloudPlayer.js";
import Enemy from "./Enemy/Enemy.js";
import Paralax from "./Paralax/Paralax.js";
import Score from "./Score/Score.js";
import Button from "./Button/Button.js";
import CloudEnemy from "./CloudEnemy/CloudEnemy.js";
import HealthBar from "./HealthBar/HealthBar.js";
import Thumnail from "./Thumnail/Thumnail.js";
import Boss from "./Boss/Boss.js";
import YouWinThing from "./YouWinThing/YouWinThing.js";
import TimeOrOnMobileEnemyPoint from "./TimeOrOnMobileEnemyPoint/TimeOrOnMobileEnemyPoint.js";
import CrosshairOrMouse from "./CrosshairOrMouse/CrosshairOrMouse.js";
import SaveCode from "./SaveCode/SaveCode.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Missiles: new Missiles({
    x: 36,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 2,
  }),
  PlayerSpaceShip: new PlayerSpaceShip({
    x: -27,
    y: -18,
    direction: 53.44036527550663,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 15,
  }),
  CloudPlayer: new CloudPlayer({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 10,
  }),
  Enemy: new Enemy({
    x: -83,
    y: 70,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.LEFT_RIGHT,
    costumeNumber: 5,
    size: 100,
    visible: false,
    layerOrder: 3,
  }),
  Paralax: new Paralax({
    x: -13.5,
    y: -9,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 1,
  }),
  Score: new Score({
    x: 220,
    y: 124,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 11,
    size: 100,
    visible: false,
    layerOrder: 4,
  }),
  Button: new Button({
    x: 0,
    y: 3,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 298.4000000000687,
    visible: true,
    layerOrder: 13,
  }),
  CloudEnemy: new CloudEnemy({
    x: 5,
    y: 212,
    direction: 0,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 9,
  }),
  HealthBar: new HealthBar({
    x: 36,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 11,
    size: 100,
    visible: false,
    layerOrder: 5,
  }),
  Thumnail: new Thumnail({
    x: -23,
    y: 2.000066801818832,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 14,
  }),
  Boss: new Boss({
    x: 0,
    y: 230,
    direction: 180,
    rotationStyle: Sprite.RotationStyle.DONT_ROTATE,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 11,
  }),
  YouWinThing: new YouWinThing({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 6,
  }),
  TimeOrOnMobileEnemyPoint: new TimeOrOnMobileEnemyPoint({
    x: 36,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 7,
  }),
  CrosshairOrMouse: new CrosshairOrMouse({
    x: 240,
    y: 180,
    direction: 98.5969371484,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 159.5,
    visible: true,
    layerOrder: 12,
  }),
  SaveCode: new SaveCode({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 8,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30, // Set to 60 to make your project run faster
});
export default project;
