/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class CrosshairOrMouse extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./CrosshairOrMouse/costumes/costume1.svg", {
        x: 7.5,
        y: 7,
      }),
    ];

    this.sounds = [new Sound("pop", "./CrosshairOrMouse/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenGreenFlagClicked() {
    yield* this.crossHair();
  }

  *crossHair() {
    this.effects.pixelate = 10;
    while (true) {
      this.goto(this.mouse.x, this.mouse.y);
      this.direction += Math.ceil(4.9);
      if (this.mouse.down || this.keyPressed("space")) {
        this.size = 125;
      } else {
        this.size += (160 - this.size) / 2;
      }
      yield;
    }
  }
}
