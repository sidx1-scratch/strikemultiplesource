/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class SaveCode extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume2", "./SaveCode/costumes/costume2.svg", {
        x: 0,
        y: 0,
      }),
    ];

    this.sounds = [new Sound("Meow", "./SaveCode/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "b" }, this.whenKeyBPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.KEY_PRESSED, { key: "c" }, this.whenKeyCPressed),
    ];

    this.vars.saveCode =
      "0|sidx1|-9|-63|100|6|15|779753322093063401061020930634010310|779753322093063401481020930634011710|779753322093063401021020930634010210|779753322093063401021020930634010210|779753322093063401021020930634010210|0|779753322093063401171020930634011710|0|0|0|0|1042|866|3|1|7975332|1|";
    this.vars.value = 1;
    this.vars.saveIdx = 280;
    this.vars.c = "|";
  }

  *writeValue(text) {
    this.vars.saveIdx = 1;
    for (let i = 0; i < text.length; i++) {
      this.vars.c = this.letterOf(text, this.vars.saveIdx - 1);
      if (this.stringIncludes("|\\", this.toString(this.vars.c))) {
        this.vars.saveCode = this.toString(this.vars.saveCode) + "\\";
      }
      this.vars.saveCode =
        this.toString(this.vars.saveCode) + this.toString(this.vars.c);
      this.vars.saveIdx++;
    }
    this.vars.saveCode = this.toString(this.vars.saveCode) + "|";
  }

  *readValue() {
    this.vars.value = "";
    while (true) {
      this.vars.c = this.letterOf(this.vars.saveCode, this.vars.saveIdx - 1);
      this.vars.saveIdx++;
      if (this.stringIncludes("|", this.toString(this.vars.c))) {
        return;
      }
      if (this.toString(this.vars.c) === "\\") {
        this.vars.c = this.letterOf(this.vars.saveCode, this.vars.saveIdx - 1);
        this.vars.saveIdx++;
      }
      this.vars.value =
        this.toString(this.vars.value) + this.toString(this.vars.c);
    }
  }

  *whenKeyBPressed() {
    yield* this.askAndWait("what is the save code?");
    this.vars.saveCode = this.answer;
    this.vars.saveIdx = 1;
    yield* this.readValue();
    this.stage.vars.score = this.vars.value;
    yield* this.readValue();
    this.stage.vars.username = this.vars.value;
    yield* this.readValue();
    this.stage.vars.x = this.vars.value;
    yield* this.readValue();
    this.stage.vars.y = this.vars.value;
    yield* this.readValue();
    this.stage.vars.health = this.vars.value;
    yield* this.readValue();
    this.stage.vars.coustume = this.vars.value;
    yield* this.readValue();
    this.stage.vars.time = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud1 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud2 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud3 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud4 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud5 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud6 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud7 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.Cloud8 = this.vars.value;
    yield* this.readValue();
    this.stage.vars.aliveOrNot = this.vars.value;
    yield* this.readValue();
    this.stage.vars.aliveOrNotEnemy = this.vars.value;
    yield* this.readValue();
    this.stage.vars.cloneIdMul = this.vars.value;
    yield* this.readValue();
    this.stage.vars.cloneNumer = this.vars.value;
    yield* this.readValue();
    this.stage.vars.cloudTick = this.vars.value;
    yield* this.readValue();
    this.stage.vars.myChannel = this.vars.value;
    yield* this.readValue();
    this.stage.vars.misilleTouch = this.vars.value;
    yield* this.readValue();
    this.stage.vars.myPlayerUid = this.vars.value;
    yield* this.readValue();
    this.stage.vars.talk = this.vars.value;
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.copyToClipboard.visible = false;
  }

  *whenKeyCPressed() {
    this.vars.saveCode = "";
    yield* this.writeValue(this.stage.vars.score);
    yield* this.writeValue(this.stage.vars.username);
    yield* this.writeValue(this.stage.vars.x);
    yield* this.writeValue(this.stage.vars.y);
    yield* this.writeValue(this.stage.vars.health);
    yield* this.writeValue(this.stage.vars.coustume);
    yield* this.writeValue(this.stage.vars.time);
    yield* this.writeValue(this.stage.vars.Cloud1);
    yield* this.writeValue(this.stage.vars.Cloud2);
    yield* this.writeValue(this.stage.vars.Cloud3);
    yield* this.writeValue(this.stage.vars.Cloud4);
    yield* this.writeValue(this.stage.vars.Cloud5);
    yield* this.writeValue(this.stage.vars.Cloud6);
    yield* this.writeValue(this.stage.vars.Cloud7);
    yield* this.writeValue(this.stage.vars.Cloud8);
    yield* this.writeValue(this.stage.vars.aliveOrNot);
    yield* this.writeValue(this.stage.vars.aliveOrNotEnemy);
    yield* this.writeValue(this.stage.vars.cloneIdMul);
    yield* this.writeValue(this.stage.vars.cloneNumer);
    yield* this.writeValue(this.stage.vars.cloudTick);
    yield* this.writeValue(this.stage.vars.myChannel);
    yield* this.writeValue(this.stage.vars.misilleTouch);
    yield* this.writeValue(this.stage.vars.myPlayerUid);
    yield* this.writeValue(this.stage.vars.talk);
    this.stage.vars.copyToClipboard = [];
    this.stage.vars.copyToClipboard.push(this.vars.saveCode);
    this.stage.watchers.copyToClipboard.visible = true;
  }
}
