/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Button/costumes/costume1.svg", {
        x: 50.88816,
        y: 50.88816,
      }),
      new Costume("costume2", "./Button/costumes/costume2.svg", {
        x: 50.88816,
        y: 50.88816,
      }),
    ];

    this.sounds = [new Sound("Bossa Nova", "./Button/sounds/Bossa Nova.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart),
      new Trigger(
        Trigger.BROADCAST,
        { name: "game over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: 0.01 },
        this.whengreaterthan
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenIReceiveStart() {
    this.effects.ghost = 100;
  }

  *whenIReceiveGameOver() {
    this.effects.ghost = 0;
    yield* this.set1();
    yield* this.set();
    this.broadcast("start");
  }

  *set() {
    this.direction = 90;
    this.y = 0 + Math.cos(this.degToRad(this.timer * 320)) * 3;
    this.broadcast("paralax");
    if (this.touching("mouse")) {
      this.costume = "costume2";
    } else {
      this.costume = "costume1";
    }
  }

  *set1() {
    this.stage.vars.start = 0;
    while (true) {
      yield* this.set();
      if (
        (this.mouse.down && this.touching("mouse")) ||
        this.keyPressed("space")
      ) {
        this.stage.vars.start = 1;
        this.broadcast("start");
      }
      if (this.toNumber(this.stage.vars.start) === 1) {
        return;
      } else {
        if (this.toNumber(this.stage.vars.start) === 0) {
          this.broadcast("game over");
        }
      }
      if (this.touching("mouse")) {
        this.size += 0.1 * (300 - this.size);
      } else {
        this.size += 0.1 * (230 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.restartTimer();
      yield;
    }
  }

  *whengreaterthan() {
    this.effects.ghost = 100;
  }

  *whenGreenFlagClicked2() {
    this.moveAhead(100);
    this.moveAhead();
    this.stage.vars.start = 0;
    this.goto(0, 0);
    this.effects.ghost = 0;
    this.visible = true;
    yield* this.set1();
  }
}
