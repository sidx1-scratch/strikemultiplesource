/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Boss extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Boss/costumes/costume1.svg", {
        x: 62.84719750000002,
        y: 62.530516677231816,
      }),
    ];

    this.sounds = [new Sound("Meow", "./Boss/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "boss" }, this.whenIReceiveBoss),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "boss end" },
        this.whenIReceiveBossEnd
      ),
    ];

    this.vars.health = 200;
  }

  *movmemet(steps) {
    this.moveAhead();
    yield* this.showHealthBarOfOffsetY(this.vars.health, 100, 50);
    this.direction = this.radToScratch(
      Math.atan2(
        this.sprites["PlayerSpaceShip"].y - this.y,
        this.sprites["PlayerSpaceShip"].x - this.x
      )
    );
    this.move(this.toNumber(steps));
    if (this.touching(this.sprites["Missiles"].andClones())) {
      this.vars.health--;
      if (this.compare(this.vars.health, 1) < 0) {
        this.stage.vars.score += 50000;
        this.visible = false;
        this.broadcast("boss end");
        return;
      }
    }
  }

  *whenIReceiveBoss() {
    this.visible = true;
    while (true) {
      this.vars.health = 200;
      yield* this.cloningForMovement(0.2);
      yield;
    }
  }

  *cloningForMovement(steps) {
    this.visible = true;
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
    while (true) {
      yield* this.movmemet(steps);
      yield;
    }
  }

  *showHealthBarOfOffsetY(health, max, y) {
    this.stage.vars.healths.push(this.x);
    this.stage.vars.healths.push(this.y + this.toNumber(y));
    this.stage.vars.healths.push(this.toNumber(health) / this.toNumber(max));
    this.sprites["HealthBar"].createClone();
  }

  *whenGreenFlagClicked() {
    this.goto(0, 300);
    this.visible = false;
  }

  *whenIReceiveBossEnd() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }
}
