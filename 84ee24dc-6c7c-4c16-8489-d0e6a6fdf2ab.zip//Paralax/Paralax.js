/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Paralax extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Paralax/costumes/costume1.svg", {
        x: 352.852855,
        y: 233.983975,
      }),
      new Costume("costume2", "./Paralax/costumes/costume2.svg", {
        x: 352.852855,
        y: 233.983975,
      }),
    ];

    this.sounds = [
      new Sound("Space Ambience", "./Paralax/sounds/Space Ambience.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "paralax" },
        this.whenIReceiveParalax
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];

    this.audioEffects.volume = 30;
  }

  *whenGreenFlagClicked() {
    this.clearPen();
    this.costume = "costume1";
    this.goto(0, 0);
    this.moveBehind();
    yield* this.setPar1();
  }

  *whenIReceiveParalax() {
    yield* this.setPar2();
  }

  *whenGreenFlagClicked2() {
    yield* this.setmus();
  }

  *setPar1() {
    while (true) {
      if (this.compare(this.sprites["PlayerSpaceShip"].x, this.x + 50) > 0) {
        this.x = this.sprites["PlayerSpaceShip"].x / 2;
        this.costume = "costume2";
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].y, this.y + 50) > 0) {
        this.y = this.sprites["PlayerSpaceShip"].y / 2;
        this.costume = "costume2";
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].x, this.x - 50) < 0) {
        this.x = this.sprites["PlayerSpaceShip"].x / 2;
        this.costume = "costume2";
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].y, this.y - 50) < 0) {
        this.y = this.sprites["PlayerSpaceShip"].y / 2;
        this.costume = "costume2";
      }
      if (
        this.sprites["PlayerSpaceShip"].x === 0 &&
        this.sprites["PlayerSpaceShip"].y === 0
      ) {
        this.goto(0, 0);
        this.costume = "costume1";
      }
      yield;
    }
  }

  *setmus() {
    while (true) {
      yield* this.playSoundUntilDone("Space Ambience");
      this.audioEffects.volume = 30;
      yield;
    }
  }

  *setPar2() {
    while (true) {
      if (this.compare(this.sprites["PlayerSpaceShip"].x, this.x) < 0) {
        this.x = this.sprites["PlayerSpaceShip"].x / 2;
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].y, this.y) < 0) {
        this.y = this.sprites["PlayerSpaceShip"].y / 2;
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].x, 50) > 0) {
        this.x = this.sprites["PlayerSpaceShip"].x / 2;
      }
      if (this.compare(this.sprites["PlayerSpaceShip"].y, this.y) > 0) {
        this.y = this.sprites["PlayerSpaceShip"].y / 2;
      }
      /* TODO: Implement sensing_setdragmode */ null;
      yield;
    }
  }
}
