/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class CloudPlayer extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./CloudPlayer/costumes/1.svg", {
        x: 48.753794098133255,
        y: 29.772552062596844,
      }),
    ];

    this.sounds = [new Sound("Meow", "./CloudPlayer/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Cloud-setup" },
        this.whenIReceiveCloudSetup
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Cloud-Tick" },
        this.whenIReceiveCloudTick
      ),
    ];

    this.vars.encodeString =
      "c76405903313322429042044309740130290420443235401692904204432382122904204440215401232904204423130362904204440145316729042044401133104290420443027301825310313322429042044309740130290420443235401692904204432382122904204440215401232904204423130362904204440145316729042044401133104290420443027301825310";
    this.vars.val = 6405903;
    this.vars.encodedIdx = 10;
    this.vars.player = 0;
    this.vars.inactive = 0;
  }

  *writeNumberToEncodedString(val) {
    this.vars.val = Math.round(this.toNumber(val));
    if (this.compare(this.vars.val, 0) < 0) {
      this.vars.val =
        "0" + this.toString(Math.abs(this.toNumber(this.vars.val)));
    }
    this.vars.encodeString =
      this.toString(this.vars.encodeString) +
      (this.toString(this.vars.val.length) + this.toString(this.vars.val));
  }

  *valReadNumberFromEncodedString() {
    this.vars.val = "";
    for (
      let i = 0;
      i <
      this.toNumber(
        this.letterOf(this.vars.encodeString, this.vars.encodedIdx - 1)
      );
      i++
    ) {
      this.vars.encodedIdx++;
      this.vars.val =
        this.toString(this.vars.val) +
        this.letterOf(this.vars.encodeString, this.vars.encodedIdx - 1);
    }
    this.vars.encodedIdx++;
    if (this.toNumber(this.letterOf(this.vars.val, 0)) === 0) {
      this.vars.val = 0 - this.toNumber(this.vars.val);
    }
  }

  *whenIReceiveCloudSetup() {
    this.visible = false;
    this.stage.vars.cloudTick = 0;
    this.stage.vars.myValuesToSend = [];
    this.stage.vars.cloudValues = [];
    this.stage.vars.playerUids = [];
    this.stage.vars.playerData = [];
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud1)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud2)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud3)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud4)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud5)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud6)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud7)
    );
    this.stage.vars.cloudValues.push(
      "c" + this.toString(this.stage.vars.Cloud8)
    );
    this.stage.vars.myPlayerUid = this.random(1, 9999999);
    this.vars.player = "";
  }

  *whenIReceiveCloudTick() {
    if (this.compare(this.vars.player, "") > 0) {
      yield* this.playerCloneTick();
      return;
    }
    this.stage.vars.cloudTick++;
    yield* this.processCloudItemValue(
      1,
      "c" + this.toString(this.stage.vars.Cloud1)
    );
    yield* this.processCloudItemValue(
      2,
      "c" + this.toString(this.stage.vars.Cloud2)
    );
    yield* this.processCloudItemValue(
      3,
      "c" + this.toString(this.stage.vars.Cloud3)
    );
    yield* this.processCloudItemValue(
      4,
      "c" + this.toString(this.stage.vars.Cloud4)
    );
    yield* this.processCloudItemValue(
      5,
      "c" + this.toString(this.stage.vars.Cloud5)
    );
    yield* this.processCloudItemValue(
      6,
      "c" + this.toString(this.stage.vars.Cloud6)
    );
    yield* this.processCloudItemValue(
      7,
      "c" + this.toString(this.stage.vars.Cloud7)
    );
    yield* this.processCloudItemValue(
      8,
      "c" + this.toString(this.stage.vars.Cloud8)
    );
    yield* this.sendMyCloudDataAfterTicks(4);
  }

  *sendMyCloudDataAfterTicks(count) {
    if (
      this.compare(
        this.toNumber(this.stage.vars.cloudTick) % this.toNumber(count),
        0
      ) > 0
    ) {
      return;
    }
    this.vars.encodeString = "";
    this.warp(this.writeNumberToEncodedString)(this.stage.vars.myPlayerUid);
    for (let i = 0; i < this.stage.vars.myValuesToSend.length; i++) {
      this.warp(this.writeNumberToEncodedString)(
        this.itemOf(this.stage.vars.myValuesToSend, 0)
      );
      this.stage.vars.myValuesToSend.splice(0, 1);
    }
    this.stage.vars.myChannel = this.random(
      1,
      this.stage.vars.cloudValues.length
    );
    if (this.compare(this.stage.vars.myChannel, 5) < 0) {
      if (this.compare(this.stage.vars.myChannel, 3) < 0) {
        if (this.compare(this.stage.vars.myChannel, 2) < 0) {
          this.stage.vars.Cloud1 = this.vars.encodeString;
        } else {
          this.stage.vars.Cloud2 = this.vars.encodeString;
        }
      } else {
        if (this.compare(this.stage.vars.myChannel, 4) < 0) {
          this.stage.vars.Cloud3 = this.vars.encodeString;
        } else {
          this.stage.vars.Cloud4 = this.vars.encodeString;
        }
      }
    } else {
      if (this.compare(this.stage.vars.myChannel, 7) < 0) {
        if (this.compare(this.stage.vars.myChannel, 6) < 0) {
          this.stage.vars.Cloud5 = this.vars.encodeString;
        } else {
          this.stage.vars.Cloud6 = 0;
        }
      } else {
        if (this.compare(this.stage.vars.myChannel, 8) < 0) {
          this.stage.vars.Cloud7 = this.vars.encodeString;
        } else {
          this.stage.vars.Cloud8 = 0;
        }
      }
    }
  }

  *processCloudItemValue(which, newValue) {
    if (
      this.compare(
        newValue,
        this.itemOf(this.stage.vars.cloudValues, which - 1)
      ) === 0
    ) {
      return;
    }
    this.stage.vars.cloudValues.splice(which - 1, 1, newValue);
    this.vars.encodeString = newValue;
    this.vars.encodedIdx = 2;
    this.warp(this.valReadNumberFromEncodedString)();
    if (
      this.compare(this.vars.val, 1) < 0 ||
      this.compare(this.vars.val, this.stage.vars.myPlayerUid) === 0
    ) {
      return;
    }
    this.vars.player =
      this.indexInArray(this.stage.vars.playerUids, this.vars.val) + 1;
    if (this.toNumber(this.vars.player) === 0) {
      this.vars.player = this.indexInArray(this.stage.vars.playerUids, "") + 1;
      if (this.toNumber(this.vars.player) === 0) {
        this.stage.vars.playerUids.push(this.vars.val);
        this.stage.vars.playerData.push("");
        this.vars.player = this.stage.vars.playerData.length;
        this.createClone();
      } else {
        this.stage.vars.playerUids.splice(
          this.vars.player - 1,
          1,
          this.vars.val
        );
      }
    }
    this.stage.vars.playerData.splice(this.vars.player - 1, 1, newValue);
    this.vars.player = "";
  }

  *playerCloneTick() {
    if (this.compare(this.vars.encodedIdx, this.vars.encodeString.length) > 0) {
      this.warp(this.getNextDataPacket)();
      if (this.toNumber(this.vars.encodeString) === 0) {
        this.vars.inactive++;
        if (this.compare(this.vars.inactive, 150) > 0) {
          this.stage.vars.playerUids.splice(this.vars.player - 1, 1, "");
          this.visible = false;
        }
        return;
      }
    }
    this.vars.inactive = 0;
    this.warp(this.valReadNumberFromEncodedString)();
    this.x = this.toNumber(this.vars.val);
    this.warp(this.valReadNumberFromEncodedString)();
    this.y = this.toNumber(this.vars.val);
    this.warp(this.valReadNumberFromEncodedString)();
    this.direction = this.toNumber(this.vars.val);
    this.warp(this.valReadNumberFromEncodedString)();
    if (this.compare(this.vars.val, this.stage.vars.aliveOrNot) === 0) {
      this.visible = true;
    } else {
      this.visible = false;
    }
    if (this.touching("mouse")) {
      this.say(this.stage.vars.username);
    }
  }

  *getNextDataPacket() {
    this.vars.encodeString = this.itemOf(
      this.stage.vars.playerData,
      this.vars.player - 1
    );
    this.stage.vars.playerData.splice(this.vars.player - 1, 1, "");
    this.vars.encodedIdx = 2;
    this.warp(this.valReadNumberFromEncodedString)();
  }
}
